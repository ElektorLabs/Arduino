/*
  twi.h - TWI/I2C library for Wiring & Arduino
  Copyright (c) 2006 Nicholas Zambetti.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

  Modified 2016 by Clemens Valens (labs@elektor.com) to add multi-peripheral support.
  Modified 2020 by Greyson Christoforo (grey@christoforo.net) to implement timeouts
  Modified 2020 by Clemens Valens <labs@elektor.com> to adapt to official iom328pb.h
*/

#ifndef twi_h
#define twi_h

#include <inttypes.h>

//#define ATMEGA8

#ifndef TWI_FREQ
#define TWI_FREQ 100000L
#endif

#ifndef TWI_BUFFER_LENGTH
#define TWI_BUFFER_LENGTH 32
#endif

#define TWI_READY 0
#define TWI_MRX   1
#define TWI_MTX   2
#define TWI_SRX   3
#define TWI_STX   4

typedef struct
{
  volatile uint8_t *twbr; // bit rate register
  volatile uint8_t *twsr; // status register
  volatile uint8_t *twar; // (slave) address register
  volatile uint8_t *twdr; // data register
  volatile uint8_t *twcr; // control register
  volatile uint8_t *twamr; // (slave) address mask register
  uint8_t sda; // SDA pin
  uint8_t scl; // SCL pin
  volatile uint8_t state;
  volatile uint8_t slarw;
  volatile uint8_t sendStop;			// should the transaction end with a stop
  volatile uint8_t inRepStart;			// in the middle of a repeated start
  void (*onSlaveTransmit)(void);
  void (*onSlaveReceive)(uint8_t*, int);
  uint8_t masterBuffer[TWI_BUFFER_LENGTH];
  volatile uint8_t masterBufferIndex;
  volatile uint8_t masterBufferLength;
  uint8_t txBuffer[TWI_BUFFER_LENGTH];
  volatile uint8_t txBufferIndex;
  volatile uint8_t txBufferLength;
  uint8_t rxBuffer[TWI_BUFFER_LENGTH];
  volatile uint8_t rxBufferIndex;
  volatile uint8_t error;
  volatile uint32_t timeout_us;
  volatile bool timed_out_flag;  // a timeout has been seen
  volatile bool do_reset_on_timeout;  // reset the TWI registers on timeout
}
twi_descriptor_t;

extern twi_descriptor_t TWI0;
extern twi_descriptor_t TWI1;

void twi_init_twi0(void);
void twi_init_twi1(void);
void twi_init(twi_descriptor_t *p_twi);
void twi_disable(twi_descriptor_t *p_twi);
void twi_setAddress(twi_descriptor_t *p_twi, uint8_t);
void twi_setFrequency(twi_descriptor_t *p_twi, uint32_t frequency);
uint8_t twi_readFrom(twi_descriptor_t *p_twi, uint8_t, uint8_t*, uint8_t, uint8_t);
uint8_t twi_writeTo(twi_descriptor_t *p_twi, uint8_t, uint8_t*, uint8_t, uint8_t, uint8_t);
uint8_t twi_transmit(twi_descriptor_t *p_twi, const uint8_t*, uint8_t);
void twi_attachSlaveRxEvent(twi_descriptor_t *p_twi, void (*)(uint8_t*, int) );
void twi_attachSlaveTxEvent(twi_descriptor_t *p_twi, void (*)(void) );
void twi_reply(twi_descriptor_t *p_twi, uint8_t);
void twi_stop(twi_descriptor_t *p_twi);
void twi_releaseBus(twi_descriptor_t *p_twi);
void twi_setTimeoutInMicros(twi_descriptor_t *p_twi, uint32_t, bool);
void twi_handleTimeout(twi_descriptor_t *p_twi, bool);
bool twi_manageTimeoutFlag(twi_descriptor_t *p_twi, bool);

#endif /* twi_h */

