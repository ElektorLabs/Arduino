/*
  pins_arduino.h - Pin definition functions for Arduino
  Part of Arduino - http://www.arduino.cc/

  Copyright (c) 2007 David A. Mellis

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

  $Id: wiring.h 249 2007-02-03 16:52:51Z mellis $
*/

#include "../standard/pins_arduino.h"
#undef NUM_ANALOG_INPUTS
#define NUM_ANALOG_INPUTS  (8)

// eRIC Nitro board has an LED on pin 9 aka PB1.
#ifdef LED_BUILTIN
#undef LED_BUILTIN
#define LED_BUILTIN  (9)

// AVR pins that are connected to the eRIC module.
#define eRIC_CD  (17) /* A3, ie PC3 */
#define eRIC_BUSY  (4) /* D4, ie PD4 */
#define eRIC_HR  (5) /* D5, ie PD5 */
#define eRIC_PIN22  (16) /* A2, ie PC2 */
